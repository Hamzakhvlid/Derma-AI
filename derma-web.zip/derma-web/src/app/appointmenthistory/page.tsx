import History from "./appointmenthistory";

export default function AppointmentHistoryPage() {
  return (
    <div className='px-7 mb-5'><History /></div>
   
  );
}