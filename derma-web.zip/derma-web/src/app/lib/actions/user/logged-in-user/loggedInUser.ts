
import { API_ROUTES } from "@/app/api/baseUrl";
import authSlice from "@/app/lib/authSlice";
import { useDispatch, useSelector } from "react-redux";

import {
  setUser,
  setIsAdmin,
} from "@/app/lib/reducers/loggedinUser/index";

export const getCurrentUser = async () => {
  

 
};


