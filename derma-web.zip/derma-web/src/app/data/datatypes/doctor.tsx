
 interface Doctor {
  id: number;
  name: string;
  specialization: string;
  email: string;
  phoneNumber: string;
  imgUrl: string;
}

export default Doctor;
