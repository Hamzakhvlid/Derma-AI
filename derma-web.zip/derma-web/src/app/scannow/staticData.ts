export const beautyTopics = [
    { name: 'Skincare Routine', selected: false },
    { name: 'Hair Care', selected: false },
    { name: 'Nail Care', selected: false },
    { name: 'Fragrances', selected: false },
    { name: 'Grooming', selected: false },
    { name: 'Clothing & Accessories', selected: false },
    { name: 'Makeup Organization & Tools', selected: false },
    { name: 'Beauty on a Budget', selected: false },
    { name: 'Beauty for Special Occasions', selected: false },
    { name: 'Men\'s Grooming', selected: false }
  ];



  export const diseaseSymptoms = [
    { name: "Redness (Erythema)", selected: false },
    { name: "Itching (Pruritus)", selected: false },
    { name: "Dryness (Xerosis)", selected: false },
    { name: "Flaking", selected: false },
    { name: "Scaling", selected: false },
    { name: "Bumps", selected: false },
    { name: "Hives", selected: false },
    { name: "Blisters", selected: false },
    { name: "Cracks", selected: false },
    { name: "Patches (Discolored Skin)", selected: false },
    { name: "Pus", selected: false },
    { name: "Crusting", selected: false },
    { name: "Oozing", selected: false },
    { name: "Bleeding", selected: false },
    { name: "Pain", selected: false },
    { name: "Burning Sensation", selected: false },
    { name: "Numbness", selected: false },
    { name: "Sweating Abnormalities (Excessive or Lack of)", selected: false },
    { name: "Hair Loss", selected: false },
    { name: "Nail Changes (Discoloration, Pitting, Cracking)", selected: false },
    { name: "Fever", selected: false },
    { name: "Peeling", selected: false },
  { name: "Bruising", selected: false },
  { name: "Swelling", selected: false },
  { name: "Changes in sensation (tingling, burning)", selected: false },
  { name: "Sensitivity to touch", selected: false },
  { name: "Changes in pigmentation", selected: false },
  { name: "Changes in texture (rough, smooth, bumpy)", selected: false },
  { name: "no pain", selected: false },
    { name: "no itching", selected: false },
    { name: "no discomfort", selected: false },

  ];