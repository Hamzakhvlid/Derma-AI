import React from 'react'
import ShuffleText from 'react-shuffle-text';

const shuffleMe = () => {
  return (
<ShuffleText content="Zhuangbility" />
  )
}

export default shuffleMe