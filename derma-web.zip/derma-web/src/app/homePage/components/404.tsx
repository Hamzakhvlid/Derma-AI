
const found = () => {
  return (
    <div>404</div>
  )
}

export default found