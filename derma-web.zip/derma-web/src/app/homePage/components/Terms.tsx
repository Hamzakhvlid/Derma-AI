

const terms = () => {
  return (
    <div>terms</div>
  )
}

export default terms