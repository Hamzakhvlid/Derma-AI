

const locatios = [
    {
        id: "lhr",
        name: "Lahore",
    },
    {
        id: "skp",
        name: "Sheikhupura",
    },
    {
        id: "sialkot",
        name: "Sialkot",
    },
    {
        id: "fsb",
        name: "Faisalabad",
    },
    {
        id: "gjrt",
        name: "Gujrat",
    },
    {
        id: "islamabad",
        name: "Islamabad",
    },
    {
        id: "pindi",
        name: "Pindi",
    },

]

export default locatios;